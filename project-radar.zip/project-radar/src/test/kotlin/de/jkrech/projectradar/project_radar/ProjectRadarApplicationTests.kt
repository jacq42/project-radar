package de.jkrech.projectradar.project_radar

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ProjectRadarApplicationTests {

	@Test
	fun contextLoads() {
	}

}
